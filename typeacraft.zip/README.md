# typeaCraft
Minecraft-like voxel game built with Three.js  
Play now @ https://rohithollabr.github.io/typeacraft/  
